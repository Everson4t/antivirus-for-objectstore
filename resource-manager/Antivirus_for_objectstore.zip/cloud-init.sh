#!/bin/bash

echo "Running $0"

su -c bash -c "$(curl -L https://raw.githubusercontent.com/Everson4t/antivirus-for-objectstore/main/bootstrap.sh)"